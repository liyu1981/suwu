import{r as e,t}from"./chunk-SHT3W25Y-COUTYvRi.js";import"./chunk-POPQ4Y6H-CdTJOJW-.js";import"./dist-MJ5sKuow.js";import"./chunk-F27PBJKO-obBFplMK.js";import"./chunk-L3NEJ4N5-CnlHJA69.js";import"./chunk-OSK3NFVY-DF6-IvaG.js";import"./chunk-GVQU2GXP-CHCbKL0e.js";import"./chunk-4HAMMTFA-CIWcENrM.js";import"./chunk-P2QGCYS3-CBhkPA_-.js";import"./chunk-GMAD6QVW-Dj6qylmn.js";import"./chunk-PWAF6VOD-C1d0e2r8.js";import"./chunk-75Z2AOVW-BM-0fsap.js";import"./chunk-DU6HZSFF-J4YaML7a.js";import"./d3-selection-COWvaQNI.js";import{n}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";var r=t({defaultLayout:`swimlane`,styles:n(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};